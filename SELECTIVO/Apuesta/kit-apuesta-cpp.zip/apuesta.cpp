#include <vector>

using namespace std;

vector<double> apuesta(vector<int> &x, vector<int> &y)
{
    return {};
}
