
using namespace std;

void inicializar(int N, int Q)
{
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

void agregar(int i, char c)
{
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

void borrar(int i, int j)
{
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

void cambiar(int i, int j)
{
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

void copiar(int i, int j)
{
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

int preguntar(int i, int j)
{
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
