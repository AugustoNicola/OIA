#include <iostream>
#include <string>
#include <cassert>

using namespace std;

void inicializar(int N, int Q);
void agregar(int i, char c);
void borrar(int i, int j);
void cambiar(int i, int j);
void copiar(int i, int j);
int preguntar(int i, int j);


int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N,Q;
    cin >> N >> Q;
    inicializar(N,Q);
    for (int qIndex=0; qIndex<Q; qIndex++)
    {
        int t; cin >> t;
        if (t == 0)
        {
            int i; cin >> i;
            string c;
            cin >> c;
            assert(c.size() == 1);
            agregar(i,c[0]);
        }
        else if (t == 1)
        {
            int i,j;
            cin >> i >> j;
            borrar(i,j);
        }
        else if (t == 2)
        {
            int i,j; 
            cin >> i >> j;
            cambiar(i,j);
        }
        else if (t == 3)
        {
            int i,j; 
            cin >> i >> j;
            copiar(i,j);
        }
        else if (t == 4)
        {
            int i,j; 
            cin >> i >> j;
            cout << preguntar(i,j) << "\n";
        }
        else
            assert(false);
    }
    return 0;
}
